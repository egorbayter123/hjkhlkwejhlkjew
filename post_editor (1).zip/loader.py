import logging

from aiogram import types, Bot

from tg_bot.config import load_config

file_log = logging.FileHandler('./tg_bot/data/log.txt')
console_out = logging.StreamHandler()

logging.basicConfig(format=u'%(filename)s [LINE:%(lineno)d] #%(levelname)-8s [%(asctime)s]  %(message)s',
                    level=logging.INFO,
                    handlers=(file_log, console_out)
                    # level=logging.DEBUG,  # Можно заменить на другой уровень логгирования.
                    )
config = load_config()
bot = Bot(token=config.bot.token, parse_mode=types.ParseMode.HTML, disable_web_page_preview=True)
