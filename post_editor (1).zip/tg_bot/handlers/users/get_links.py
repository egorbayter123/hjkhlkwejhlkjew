import logging
from typing import Union

from aiogram import types
from aiogram.dispatcher import FSMContext

from tg_bot.states import EditPostsState
from tg_bot.keyboards.reply import return_start_menu_keyboard


async def get_links(query: Union[types.CallbackQuery, types.Message], state: FSMContext):  # Ждем получения ссылок на посты которые будут отредактированы
    logging.info("Ожидание получения ссылки.")

    await EditPostsState.WAIT_LINKS.set()
    if type(query) == types.CallbackQuery:
        await query.message.answer("<b>🔗 Получение ссылок</b>\n\nЖду от тебя ссылки на посты для редактирования.", reply_markup=return_start_menu_keyboard)
        await query.answer()
    elif type(query) == types.Message:
        await query.answer("<b>🔗 Получение ссылок</b>\n\nЖду от тебя ссылки на посты для редактирования.", reply_markup=return_start_menu_keyboard)
