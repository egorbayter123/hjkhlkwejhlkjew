import asyncio
import logging
from typing import Union

import aiohttp
from aiogram import types, Bot
from aiogram.dispatcher import FSMContext
from aiogram.types import InlineKeyboardMarkup
from aiogram.utils.exceptions import BadRequest, MessageNotModified, MessageToEditNotFound, Unauthorized, ChatNotFound, MessageIdInvalid

from tg_bot.config import Config
from tg_bot.keyboards.inline import start_edit_posts_keyboard
from tg_bot.models import Post


async def start_edit_posts_menu(query: types.CallbackQuery, state: FSMContext):  # Text("edit_post_menu:continue")
    state_data: dict = await state.get_data()
    posts_list: list[Post] = state_data.get("posts_list")
    offers_data: list[dict] = state_data.get("offers_data")
    post_text: str = state_data.get("post_text")
    post_keyboard: InlineKeyboardMarkup = state_data.get("post_keyboard")

    offers_data.append({
        "posts_list": posts_list,
        "post_text": post_text,
        "post_keyboard": post_keyboard
    })

    await query.message.edit_text("<b>🗝 Меню выбора</b>", reply_markup=start_edit_posts_keyboard)

    await state.update_data(offers_data=offers_data)

    await query.answer()

    logging.info("Вопрос о запуске.")


async def start_edit_posts(query: types.CallbackQuery, state: FSMContext):
    await query.answer()

    state_data: dict = await state.get_data()

    offers_data: list[dict] = state_data.get("offers_data")

    all_failed: int = 0
    all_successfully: int = 0
    count_posts: int = 0

    bot: Bot = query.bot

    logging.info(f"offers_data: {offers_data}")

    offer_messages_list: list[types.Message] = []

    for i, offer_data in enumerate(offers_data):
        posts_list: list[Post] = offer_data["posts_list"]
        remains = len(posts_list)
        count_posts += len(posts_list)

        offer_number = i + 1

        offer_message: types.Message = await query.message.answer(f"<b>🚀 Оффер #{offer_number}</b>\n\n<b>Успешно:</b> 0\n<b>Не удалось:</b> 0\n<b>Осталось:</b> {remains}")  # Сообщение у админа
        offer_messages_list.append(offer_message)

    final_edit_message: types.Message = await query.message.reply(
        f"<b>🚀 Редактирование запущено</b>\n\n<b>Всего: </b> {count_posts}\n<b>Успешно:</b> {all_successfully}\n<b>Не удалось:</b> {all_failed}\n")

    for i, offer_data in enumerate(offers_data):
        offer_number = i + 1

        posts_list: list[Post] = offer_data["posts_list"]
        post_text: str = offer_data["post_text"]
        post_keyboard: InlineKeyboardMarkup = offer_data["post_keyboard"]

        failed: int = 0
        successfully: int = 0
        remains: int = len(posts_list)

        offer_message: types.Message = offer_messages_list[i]

        for post in posts_list:
            post: Post
            entity = post.entity
            message_id = post.message_id

            remains -= 1

            await asyncio.sleep(3)

            is_edit_post: bool = await edit_post(bot=bot, entity=entity, message_id=message_id, post_text=post_text, post_keyboard=post_keyboard, offer_message=offer_message)

            if is_edit_post:
                successfully += 1
                all_successfully += 1
            else:
                failed += 1
                all_failed += 1

            await offer_message.edit_text(f"<b>🚀 Оффер #{offer_number}</b>\n\n<b>Успешно:</b> {successfully}\n<b>Не удалось:</b> {failed}\n<b>Осталось:</b> {remains}")
            await final_edit_message.edit_text(f"<b>🚀 Редактирование запущено</b>\n\n<b>Всего: </b> {count_posts}\n<b>Успешно:</b> {all_successfully}\n<b>Не удалось:</b> {all_failed}\n")

        await offer_message.edit_text(f"<b>➕ Редактирование оффера #{offer_number} завершено</b>\n\n<b>Успешно:</b> {successfully}\n<b>Не удалось:</b> {failed}")

    await final_edit_message.reply(f"<b>✅ Редактирование завершено</b>\n\n<b>Всего:</b> {count_posts}\n<b>Успешно:</b> {all_successfully}\n<b>Не удалось:</b> {all_failed}\n")
    logging.info("Редактирование всех офферов завершено!")


async def edit_post(bot: Bot, offer_message: types.Message, entity: Union[str, int], message_id: int, post_text: str, post_keyboard: InlineKeyboardMarkup) -> bool:
    config: Config = bot.get("config")

    try:
        post_message: types.Message = await bot.forward_message(chat_id=config.bot.test_channel_id, from_chat_id=entity,
                                                                message_id=message_id)  # Единственный способ получить сообщение для проверки клавиатуру который я нашел это пересылка (сорямба за костыль:))
        await post_message.delete()

    except ChatNotFound:
        logging.info(f"ChatNotFound: Чат не найден! Message_ID: {message_id}. Entity: {entity}.")
        if isinstance(entity, str):
            await offer_message.reply(f"❗️ Пост https://t.me/{entity[1:]}/{message_id} не найден!")
        elif isinstance(entity, int):
            await offer_message.reply(f"❗️ Пост https://t.me/c/{str(entity)[4:]}/{message_id} не найден!")

        return False

    except MessageIdInvalid:
        logging.info(f"MessageIdInvalid: Сообщение не найдено! Message_ID: {message_id}. Entity: {entity}.")

        if isinstance(entity, str):
            await offer_message.reply(f"❗️ Пост https://t.me/{entity[1:]}/{message_id} не найден!")
        elif isinstance(entity, int):
            await offer_message.reply(f"❗️ Пост https://t.me/c/{str(entity)[4:]}/{message_id} не найден!")

        return False

    reply_markup = post_message["reply_markup"]

    if reply_markup is None:
        has_reply_markup: bool = False
    else:
        has_reply_markup: bool = True

    try:
        # print(f"has_reply_markup = {has_reply_markup}")
        # print(f"post_text = {post_text}")
        # print(f"post_keyboard = {post_keyboard}")
        # print(f"message_id = {message_id}, type message_id: {type(message_id)}")
        # print(f"entity = {entity}")

        # print(post_message)

        if has_reply_markup:
            logging.info("Есть клавиатура >> Редактирую через Fleep")
            async with aiohttp.ClientSession() as session:
                fleep_token: str = config.bot.fleep_token
                resp = await session.get(
                    f"https://api.telegram.org/bot{fleep_token}/editMessageCaption?chat_id={entity}&message_id={message_id}&caption={post_text}&reply_markup={post_keyboard}&parse_mode=HTML")
                if resp.status == 200:
                    return True
                else:
                    return False

            # await bot.edit_message_caption(chat_id=entity, message_id=message_id, caption=post_text, reply_markup=reply_markup)
        else:
            logging.info("Клавиатуры нет >> Редактирую через Редачер Постов")
            await bot.edit_message_caption(chat_id=entity, message_id=message_id, caption=post_text)
            return True

    except MessageNotModified:
        logging.info("Сообщение не может быть отредактировано т.к совпадает.")
        return True

    except MessageToEditNotFound:
        logging.info(f"Сообщение не найдено! Message_ID: {message_id}. Entity: {entity}.")
        if isinstance(entity, str):
            await offer_message.reply(f"❗️ Пост https://t.me/{entity[1:]}/{message_id} не найден!")
        elif isinstance(entity, int):
            await offer_message.reply(f"❗️ Пост https://t.me/c/{str(entity)[4:]}/{message_id} не найден!")

        return False

    except Unauthorized:
        logging.info(f"Доступ запрещен! Message_ID: {message_id}. Entity: {entity}.")
        if isinstance(entity, str):
            await offer_message.reply(f"❗️ Пост https://t.me/{entity[1:]}/{message_id} не может быть отредактирован так как нету админки/прав на редактирование.")
        elif isinstance(entity, int):
            await offer_message.reply(f"❗️ Пост https://t.me/c/{str(entity)[4:]}/{message_id} не может быть отредактирован так как нету админки/прав на редактирование.")

        return False
    except BadRequest:
        try:
            if has_reply_markup:
                await bot.edit_message_text(chat_id=entity, message_id=message_id, text=post_text, reply_markup=post_keyboard)
            else:
                await bot.edit_message_text(chat_id=entity, message_id=message_id, text=post_text)

            return True

        except MessageNotModified:
            logging.info("Сообщение не может быть отредактировано т.к совпадает.")
            return True

        except Exception as e:
            logging.exception(f"Произошла ошибка! Ошибка > {e}. Message_ID: {message_id}. Entity: {entity}. ")

            return False

    except Exception as e:
        logging.exception(f"Произошла ошибка! Ошибка > {e}. Message_ID: {message_id}. Entity: {entity}. ")

        return False
    else:
        logging.info("Пост успешно отредактирован.")
