import logging
from typing import Union

from aiogram import types
from aiogram.dispatcher import FSMContext

from tg_bot.keyboards.reply import start_menu_keyboard


async def start_menu(message: types.Message, state: FSMContext):
    await state.finish()

    edit_message_id: int = message.message_id
    offers_data: list[dict] = []

    await state.update_data(edit_message_id=edit_message_id, offers_data=offers_data)
    await message.reply("Привет, ты в главном меню!", reply_markup=start_menu_keyboard)

    logging.info("Прописана команда /start.")


async def return_start_menu(message: types.Message, state: FSMContext):
    await state.finish()

    edit_message_id: int = message.message_id
    offers_data: list[dict] = []

    await state.update_data(edit_message_id=edit_message_id, offers_data=offers_data)
    await message.answer("Привет, ты в главном меню!", reply_markup=start_menu_keyboard)

    logging.info("Возвращение в главное меню.")
