from aiogram.dispatcher import FSMContext
from aiogram import types
from aiogram.types import InputFile


async def get_logs(query: types.CallbackQuery, state: FSMContext):
    logs_file = InputFile("./tg_bot/data/log.txt")

    await query.message.answer_document(document=logs_file)
    await query.answer()