from aiogram import types
from aiogram.dispatcher import FSMContext

from tg_bot.keyboards.inline import admin_keyboard


async def start_admin_menu(message: types.Message, state: FSMContext):
    await state.reset_state(with_data=False)

    await state.update_data(message_id=message.message_id)

    await message.answer(
        '<b>🎅🏽 Админ-панель</b>',
        reply_markup=admin_keyboard)


async def return_admin_menu(query: types.CallbackQuery, state: FSMContext):
    await state.reset_state(with_data=False)

    await query.message.edit_text(
        '<b>🎅🏽 Админ-панель</b>',
        reply_markup=admin_keyboard)
