import logging

from aiogram import types
from aiogram.dispatcher.filters import BoundFilter

from tg_bot.config import Config


class AdminFilter(BoundFilter):
    key = 'is_admin'

    def __init__(self, is_admin):
        self.is_admin = is_admin

    async def check(self, message: types.Message) -> bool:
        config: Config = message.bot.get("config")

        is_admin_bool = message.from_user.id in config.bot.admins

        logging.debug(f"is_admin = {is_admin_bool}")

        return is_admin_bool
