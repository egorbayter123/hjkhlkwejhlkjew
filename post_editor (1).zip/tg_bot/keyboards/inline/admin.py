from aiogram.types import InlineKeyboardButton, InlineKeyboardMarkup

return_admin_btn = InlineKeyboardButton("Вернуться назад", callback_data="return_admin_menu")
return_admin_keyboard = InlineKeyboardMarkup().add(return_admin_btn)

add_admin_btn = InlineKeyboardButton("➕ Добавить админа", callback_data="add_admin")
delete_admin_btn = InlineKeyboardButton("➖ Убрать админа", callback_data="delete_admin")
get_logs_admin_btn = InlineKeyboardButton("✍🏽 Получить файл с логами", callback_data="get_logs_admin")

admin_keyboard = InlineKeyboardMarkup(row_width=2).add(add_admin_btn, delete_admin_btn, get_logs_admin_btn)