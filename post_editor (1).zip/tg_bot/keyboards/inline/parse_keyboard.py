import logging
from typing import Union

from aiogram.types import InlineKeyboardMarkup, InlineKeyboardButton


async def parse_keyboard(buttons_markup: str) -> Union[None, InlineKeyboardMarkup]:
    keyboard = InlineKeyboardMarkup(row_width=3)
    try:
        for row in buttons_markup.split("\n"):
            buttons_row: list[InlineKeyboardButton] = []
            row_data = row.split(" | ")

            for button_data in row_data:
                button_data = button_data.split(" - ")
                button_text = button_data[0]
                button_url = button_data[1]

                buttons_row.append(InlineKeyboardButton(button_text, url=button_url))

            keyboard.row(*buttons_row)
            logging.info("Клавиатура успешно спаршена.")
    except Exception as e:
        logging.info(f"Была получена неправильная клавиатура. Сработало исключение {e}. Возвращено None.")
        return None

    return keyboard
